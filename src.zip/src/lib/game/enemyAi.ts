// src/lib/game/enemyAi.ts
// ─── Sistema de IA de Enemigos ────────────────────────────────────────────────

import {
  AiTier,
  EnemyAction,
  EnemyAiState,
  EnemyActionResult,
  BossPhase,
  EnemyCombatState,
} from '@/types/game'

// ─── Contexto de combate ──────────────────────────────────────────────────────

export interface EnemyCombatContext {
  playerHP: number
  playerMaxHP: number
  playerStamina: number
  playerMaxStamina: number
  playerMana: number
  playerMaxMana: number
  playerActiveEffects: string[]
  selfHP: number
  selfMaxHP: number
  selfActiveEffects: string[]
  turn: number
  aliveEnemyCount: number
}

// ─── Tier: dumb ───────────────────────────────────────────────────────────────
// Ataca siempre. Al llegar a energy_threshold, usa su habilidad especial.

function resolveDumb(
  actions: EnemyAction[],
  aiState: EnemyAiState,
  threshold: number
): { action: EnemyAction; resetEnergy: boolean } {
  const nextEnergy = aiState.energy + 1

  if (nextEnergy >= threshold) {
    const special = actions
      .filter(a => a.type !== 'attack' || (a.effect.damage_multiplier ?? 1) !== 1.0)
      .sort((a, b) => b.base_weight - a.base_weight)[0]
    return { action: special ?? actions[0], resetEnergy: true }
  }

  const normal = actions
    .filter(a => a.type === 'attack')
    .sort((a, b) => (a.effect.damage_multiplier ?? 1) - (b.effect.damage_multiplier ?? 1))[0]
    ?? actions[0]
  return { action: normal, resetEnergy: false }
}

// ─── Tier: medium ─────────────────────────────────────────────────────────────
// Pesos contextuales — reacciona al estado sin anticipar.

function weightedSample(actions: EnemyAction[], weights: number[]): EnemyAction {
  const total = weights.reduce((s, w) => s + w, 0)
  let r = Math.random() * total
  for (let i = 0; i < actions.length; i++) {
    r -= weights[i]
    if (r <= 0) return actions[i]
  }
  return actions[actions.length - 1]
}

function resolveMedium(actions: EnemyAction[], ctx: EnemyCombatContext): EnemyAction {
  const selfHpPct   = ctx.selfHP   / ctx.selfMaxHP
  const playerHpPct = ctx.playerHP / ctx.playerMaxHP

  const weights = actions.map(a => {
    let w = a.base_weight
    if (a.type === 'heal' && selfHpPct < 0.30) w += 40
    if (a.type === 'heal' && selfHpPct < 0.50) w += 20
    if (a.type === 'attack' && ctx.playerActiveEffects.length > 0) w += 15
    if (a.type === 'attack' && playerHpPct < 0.25 && (a.effect.damage_multiplier ?? 1) > 1.2) w += 25
    if (ctx.turn % 2 === 0 && a.type === 'skill') w += 10
    return Math.max(1, w)
  })

  return weightedSample(actions, weights)
}

// ─── Tier: smart ──────────────────────────────────────────────────────────────
// Árbol de decisión generalizado por tipos y efectos — sin hardcodear nombres.

function resolveSmart(actions: EnemyAction[], ctx: EnemyCombatContext): EnemyAction {
  const selfHpPct   = ctx.selfHP   / ctx.selfMaxHP
  const playerHpPct = ctx.playerHP / ctx.playerMaxHP

  const healAction   = actions.find(a => a.type === 'heal')
  const poisonAction = actions.find(a => a.type === 'skill' && a.effect.apply_effect === 'poison')
  const stunAction   = actions.find(a => a.type === 'skill' && a.effect.apply_effect === 'stun')
  const strongAtk    = actions
    .filter(a => a.type === 'attack')
    .sort((a, b) => (b.effect.damage_multiplier ?? 1) - (a.effect.damage_multiplier ?? 1))[0]
  const normalAtk    = actions
    .filter(a => a.type === 'attack')
    .sort((a, b) => (a.effect.damage_multiplier ?? 1) - (b.effect.damage_multiplier ?? 1))[0]

  const playerPoisoned = ctx.playerActiveEffects.includes('poison')
  const playerStunned  = ctx.playerActiveEffects.includes('stun')

  // 1. Curar si HP crítico (<20%)
  if (selfHpPct < 0.20 && healAction) return healAction

  // 2. Remate si jugador casi muerto (<20%)
  if (playerHpPct < 0.20 && strongAtk) return strongAtk

  // 3. Stun si jugador tiene recursos altos y no está stunneado
  if (!playerStunned && stunAction &&
      ctx.playerStamina > ctx.playerMaxStamina * 0.6 &&
      ctx.playerMana    > ctx.playerMaxMana    * 0.6) {
    return stunAction
  }

  // 4. Veneno si jugador no está envenenado y tiene HP alto
  if (!playerPoisoned && poisonAction && playerHpPct > 0.40) return poisonAction

  // 5. Curar si HP moderado (<40%)
  if (selfHpPct < 0.40 && healAction) return healAction

  // 6. Ataque fuerte si jugador en HP medio
  if (playerHpPct < 0.50 && strongAtk && (strongAtk.effect.damage_multiplier ?? 1) > 1.3) {
    return strongAtk
  }

  // 7. Fallback: ataque normal
  return normalAtk ?? actions[0]
}

// ─── Resolución de acción → EnemyActionResult ─────────────────────────────────

function buildActionResult(
  action: EnemyAction,
  enemyAttack: number,
  selfMaxHP: number,
  selfCurrentHP: number,
  capPlayerDamage: boolean
): EnemyActionResult {
  const log: string[] = []
  let damageToPlayer = 0
  let selfHeal = 0
  const newPlayerEffects: string[] = []
  let summonEnemyId: number | null = null

  switch (action.type) {
    case 'attack': {
      const mult = action.effect.damage_multiplier ?? 1.0
      const base = enemyAttack * mult
      damageToPlayer = Math.max(1, Math.round(base * (0.8 + Math.random() * 0.4)))
      log.push(`👹 ${action.label} por ${damageToPlayer} de daño!`)
      break
    }
    case 'skill': {
      if (action.effect.apply_effect) {
        newPlayerEffects.push(action.effect.apply_effect)
        log.push(`💀 ${action.label}!`)
      }
      break
    }
    case 'heal': {
      const pct = action.effect.heal_pct ?? 0.20
      selfHeal = Math.round(selfMaxHP * pct)
      const actualHeal = Math.min(selfHeal, selfMaxHP - selfCurrentHP)
      log.push(`💚 ${action.label} recupera ${actualHeal} HP!`)
      break
    }
    case 'summon': {
      summonEnemyId = action.effect.summon_enemy_id ?? null
      log.push(`🔔 ${action.label}!`)
      break
    }
    case 'buff': {
      log.push(`✨ ${action.label}!`)
      break
    }
  }

  return { action, damageToPlayer, selfHeal, newPlayerEffects, summonEnemyId, capPlayerDamage, log }
}

// ─── Evaluación de fases de boss ──────────────────────────────────────────────

export function evaluateBossPhase(
  phases: BossPhase[],
  currentHP: number,
  maxHP: number,
  triggeredPhases: number[]
): BossPhase | null {
  const hpPct = currentHP / maxHP
  const sorted = [...phases].sort((a, b) => b.hp_threshold - a.hp_threshold)
  for (const phase of sorted) {
    if (hpPct <= phase.hp_threshold && !triggeredPhases.includes(phase.phase_order)) {
      return phase
    }
  }
  return null
}

// ─── Función principal ────────────────────────────────────────────────────────

export interface ResolveEnemyActionInput {
  enemy: EnemyCombatState
  availableActions: EnemyAction[]
  aiState: EnemyAiState
  ctx: EnemyCombatContext
  phases?: BossPhase[]
  activePhaseAction?: EnemyAction | null
  capPlayerDamage?: boolean
  // energy_threshold de la DB (para tier dumb)
  energyThreshold?: number
}

export interface ResolveEnemyActionOutput {
  result: EnemyActionResult
  newAiState: EnemyAiState
}

export function resolveEnemyAction(input: ResolveEnemyActionInput): ResolveEnemyActionOutput {
  const { enemy, availableActions, aiState, ctx } = input
  const capPlayerDamage = input.capPlayerDamage ?? false

  // Acción de fase prioritaria
  if (input.activePhaseAction) {
    const result = buildActionResult(
      input.activePhaseAction,
      enemy.enemy.stats.attack * (enemy.statMults?.attack_mult ?? 1),
      enemy.maxHP, enemy.currentHP, capPlayerDamage
    )
    return { result, newAiState: { ...aiState } }
  }

  // Sin acciones configuradas → ataque genérico
  if (!availableActions.length) {
    const fallback: EnemyAction = {
      id: -1, name: 'fallback',
      label: `${enemy.enemy.name} ataca`,
      type: 'attack', base_weight: 100,
      effect: { damage_multiplier: 1.0 },
    }
    const result = buildActionResult(
      fallback,
      enemy.enemy.stats.attack * (enemy.statMults?.attack_mult ?? 1),
      enemy.maxHP, enemy.currentHP, capPlayerDamage
    )
    return { result, newAiState: { ...aiState } }
  }

  const effectiveAttack = enemy.enemy.stats.attack * (enemy.statMults?.attack_mult ?? 1)
  let chosenAction: EnemyAction
  let newEnergy = aiState.energy

  switch (aiState.tier) {
    case 'dumb': {
      const threshold = input.energyThreshold ?? 3
      const { action, resetEnergy } = resolveDumb(availableActions, aiState, threshold)
      chosenAction = action
      newEnergy = resetEnergy ? 0 : aiState.energy + 1
      break
    }
    case 'medium':
      chosenAction = resolveMedium(availableActions, ctx)
      break
    case 'smart':
    case 'boss':
      chosenAction = resolveSmart(availableActions, ctx)
      break
    default:
      chosenAction = availableActions.find(a => a.type === 'attack') ?? availableActions[0]
  }

  const result = buildActionResult(
    chosenAction, effectiveAttack, enemy.maxHP, enemy.currentHP, capPlayerDamage
  )

  return { result, newAiState: { ...aiState, energy: newEnergy } }
}

// ─── Helper: inicializar aiState ──────────────────────────────────────────────

export function initAiState(tier: AiTier): EnemyAiState {
  return { tier, energy: 0, activePhaseOrder: 0, triggeredPhases: [] }
}